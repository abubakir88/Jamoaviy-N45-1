// 1///////////////////////////////////
// function kkk(n) {
//   let a = "";
//   for (let i = 0; i < n; i++) {
//     a += String.fromCharCode(65 + i);
//   }
//   return a;
// }

// console.log(kkk(5));

// 2///////////////////////////////////
// function kkk(char) {
//   let c = char.charCodeAt(0);
//   if (c >= 48 && c <= 57) {
//     return "a";
//   }
//   if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) {
//     return "b";
//   }
//   return 0;
// }
// console.log(kkk("a"));

// 4///////////////////////////////////
// function str(string) {
//   let length = string.length;
//   if (length === 0) {
//     return NaN;
//   }
//   let firstCode = string.charCodeAt(0);
//   let lastCode = string.charCodeAt(length - 1);
//   let c = [firstCode, lastCode];
//   return c;
// }
// console.log(str("hello"));

// 6///////////////////////////////////
// let Number = "9980097667";
// let fourDigits = Number.slice(5);
// let newStr = fourDigits.padStart(9, "*");
// console.log(newStr);

// 7///////////////////////////////////
// let s1 = +prompt("a");
// let s2 = +prompt("b");
// if (s1 > s2) {
//   let n = (s1 = s2 === Nan);
//   console.log(n);
// } else s1 >= s2;
// {
//   let i = s1 >= s2 + 1;
//   console.log(i);
// }

// 10////////////////////
// function kkk(num) {
//   let digits = 0;
//   let sum = 0;
//   let str = num.toString();
//   digits = str.length;
//   for (let i = 0; i < str.length; i++) {
//     sum += parseInt(str[i]);
//   }
//   console.log(digits);
// }
